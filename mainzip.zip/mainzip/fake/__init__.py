import glob
import random

class Fake:  
    def first_name():
        with open("fake/first_name/base.txt", "r", encoding="utf-8") as file:
            first_names = file.read().split("\n")
            
        return random.choice(first_names)

    def about():
        with open("fake/bio/base.txt", "r", encoding="utf-8") as file:
            abouts = file.read().split("\n")
            
        return random.choice(abouts)

    def username():
        with open("fake/username/base.txt", "r", encoding="utf-8") as file:
            usernames = file.read().split("\n")
            
        choice_username = random.choice(usernames)
        return str(choice_username) + str(random.randint(10000, 90000))

    def profile():
        profiles = []
        
        for pic in glob.glob("fake/profile/*.jpg"):
            profiles.append(pic)
            
        return random.choice(profiles).replace("\\", "/")