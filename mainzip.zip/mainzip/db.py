from datetime import datetime
from localdb import Database
from config import OWNER

dB = Database("Database1.json")
udB = Database("Database2.json")
cdB = Database("Database3.json")
cpdb = Database("Database4.json")

def add_(user_id: str, amount: int,var:str):
    data = dB.get(var) or {}
    sed = get_(user_id,var)
    print(sed)
    if data.get(user_id):
        data.update({user_id:float(sed ) + float(amount)})
    else:
        data.update({user_id:float(amount)})
    return dB.set(var, data)

def get_(user_id: str,var:str):
    data = dB.get(var) or {}
    if data.get(user_id):
        return data.get(user_id)
    else:
        return 0

def dedu(user_id: str, amount: int,var:str):
    data = dB.get(var) or {}
    sed = get_(user_id,var)
    if data.get(user_id):
        data.update({user_id:float(sed)  - float(amount)})
    else:
        data.update({user_id:amount})
    return dB.set(var, data)



def zero_(user_id: str):
    data = dB.get("claim") or {}
    sed = get_(user_id,"claim")
    if data.get(user_id):
        data.update({user_id:0})
    else:
        data.update({user_id:0})
    return dB.set("claim", data)


def arzero_(user_id: str):
    data = dB.get("AR") or {}
    sed = get_(user_id,"AR")
    if data.get(user_id):
        data.update({user_id:0})
    else:
        data.update({user_id:0})
    return dB.set("AR", data)

def add_history(user_id: str,txt: int,var:str):
    data = dB.get(var) or {}
    sed = get_(user_id,var)
    now = datetime.now()
    date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
    updt = f"{sed}\n{txt}: {date_time}"
    if data.get(user_id):
        data.update({user_id:updt})
    else:
        data.update({user_id:updt})
    return dB.set(var, data)

if not udB.get("users"):
    udB.set("users", [OWNER])
    
if not udB.get("bans"):
    udB.set("bans", [0])
    
if not udB.get("actives"):
    udB.set("actives", [0])
    
if not udB.get("SESSION_PASSWORD"):
    udB.set("SESSION_PASSWORD", "196666")