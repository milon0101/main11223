import os
import sqlite3

class Session:
    def __init__(
        self,
        auth_key: bytes = None,
        server_address: str = None,
        port: int = None,
        is_bot: int = 0,
        dc_id: int = None,
        test_mode: int = None,
    ):
        self._auth_key = auth_key
        self._server_adderss = server_address
        self._port = port
        self._user_id = 1
        self._is_bot = is_bot
        self._dc_id = dc_id
        self._test_mode = test_mode
        self._takeout_id = None  # Not required for pyrogram or telethon
        self._loaded = False

    @property
    def loaded(self):
        return self._loaded

    @property
    def test_mode(self):
        if self._port is not None:
            return self._port == 80
        return self._test_mode

    @property
    def dc_id(self):
        return self._dc_id

    @property
    def user_id(self):
        return self._user_id

    @property
    def is_bot(self):
        return self._is_bot

    @property
    def auth_key(self):
        return self._auth_key

    @property
    def takeout_id(self):
        return self._takeout_id

    @property
    def port(self):
        if self._port is None and self.test_mode is not None:
            return 80 if self.test_mode else 443
        return self._port

    @property
    def server_address(self):
        if self._server_adderss is None and self.dc_id is not None:
            TEST = {
                1: "149.154.175.10",
                2: "149.154.167.40",
                3: "149.154.175.117",
                121: "95.213.217.195",
            }
            PROD = {
                1: "149.154.175.53",
                2: "149.154.167.51",
                3: "149.154.175.100",
                4: "149.154.167.91",
                5: "91.108.56.130",
                121: "95.213.217.195",
            }
            self._server_adderss = (
                TEST[self.dc_id] if self.test_mode else PROD[self.dc_id]
            )
        return self._server_adderss

    async def load_pyrogram_session(self, session: str):
        try:
            conn = sqlite3.connect(session, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            get = conn.execute("select * from sessions").fetchone()
                
            self._dc_id = get['dc_id']
            self._test_mode = get['test_mode']
            self._auth_key = get['auth_key']
            self._date = get['date']
            self._user_id = get['user_id']
            self._is_bot = get['is_bot']
            
            self._loaded = True
            conn.close()
        finally:
            return self._loaded

    async def generate_telethon_session_file(self, session_path: str):
        if not self.loaded:
            raise ValueError("Session not loaded")

        if os.path.exists(session_path):
            os.remove(session_path)

        conn = sqlite3.connect(session_path, check_same_thread=False)
        for table in TELETHON_TABLES:
            conn.execute("create table if not exists {}".format(table))

        conn.execute("insert into version values (?)", (7,))
        conn.execute(
            "insert or replace into sessions values (?,?,?,?,?)",
            (
                self.dc_id,
                self.server_address,
                self.port,
                self.auth_key,
                self.takeout_id,
            ),
        )
        conn.commit()
        conn.close()
        return True

TELETHON_TABLES = [
    "version (version integer primary key)",
    """sessions (
                dc_id integer primary key,
                server_address text,
                port integer,
                auth_key blob,
                takeout_id integer
            )""",
    """entities (
                id integer primary key,
                hash integer not null,
                username text,
                phone integer,
                name text,
                date integer
            )""",
    """sent_files (
                md5_digest blob,
                file_size integer,
                type integer,
                id integer,
                hash integer,
                primary key(md5_digest, file_size, type)
            )""",
    """update_state (
                id integer primary key,
                pts integer,
                qts integer,
                date integer,
                seq integer
            )""",
]